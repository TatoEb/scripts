#Persistent
current := 0
paused := false

^Space::  ; Ctrl + Space — pause / running again
paused := !paused
if (paused) {
    SetTimer, CycleWindows, Off
    TrayTip, AutoSwitcher, Paused., 800, 1
} else {
    SetRandomTimer()
    TrayTip, AutoSwitcher, Running again., 800, 1
}
return

SetRandomTimer() {
    Random, delay, 3000, 4000  ; Random delay 3000 - 4000 msec
    SetTimer, CycleWindows, %delay%
}

CycleWindows:
    WinGet, winList, List
    validCount := 0

    ; getting the windows with the titles only
    Loop, %winList%
    {
        winID := winList%A_Index%
        WinGetTitle, title, ahk_id %winID%
        WinGet, style, Style, ahk_id %winID%

        if (title != "" && (style & 0x10000000))  ; WS_VISIBLE
        {
            validCount += 1
            validWindows%validCount% := winID
        }
    }

    if (validCount > 0) {
        current += 1
        if (current > validCount)
            current := 1

        thisID := validWindows%current%
        WinActivate, ahk_id %thisID%
    }

    ; Clear the massive
    Loop, %validCount%
        validWindows%A_Index% := ""

    ; Set random pause
    SetRandomTimer()
return
